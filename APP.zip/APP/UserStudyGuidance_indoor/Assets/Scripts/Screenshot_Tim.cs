﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using System.IO;
using System;
using TMPro;
using System.Text;
using System.Linq;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using Unity.Collections.LowLevel.Unsafe;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

using System.Threading.Tasks;
using UnityEngine.Experimental.Rendering;
using UnityEngine.Rendering;


public class Screenshot_Tim : MonoBehaviour
{
    ARCameraManager m_CameraManager;//remember to drag ARCamera to it

    bool takePicture = false;
    bool froze = false;


    public TextMeshProUGUI suggestedLabel;
    public TextMeshProUGUI ChooseCorrectBBMessage;
    public TextMeshProUGUI ChooseCorrectLabelMessage;
    public GUISkin guiSkin;
    public Texture BoxTexture;
    public GameObject Correctbtn_prefab;
    Button[] correctbtn_list = new Button[10];
    public GameObject NotCorrectbtn_prefab;
    Button[] notcorrectbtn_list = new Button[10];
    public GameObject cancelbtn_prefab;
    Button[] cancelbtn_list = new Button[10];
    public GameObject Canvas_prefab;
    public Button confirmAdjustBB;
    public Button confirmAll;
    public Button LU;
    public Button RB;
    public Button Classbtn1;
    public Button Classbtn2;
    public Button Classbtn3;
    public Button Classbtn4;
    public Button Classbtn5;
    Rect[] boundingBox_list = new Rect[10];
    float[,] boundingBox_label_array = new float[10,2];
    int[] showcorrectbtn_list;
    bool renderBB = false;
    public Button clickableBoundingBox;

    private readonly string url = "http://172.28.57.41:9000/predict"; //change 127.0.0.1 to my smartphone ip address
    private readonly string url2 = "http://172.28.57.41:9000/saveLabel"; //change 127.0.0.1 to my smartphone ip address

    private float xMin = 0;
    private float xMax = 100;
    private float yMin = 0;
    private float yMax = 100;
    private int numLabels;
    private string[] class_list = new string[10];
    private int swidth;
    private int sheight;
    private bool adjustBB = false;
    private string selectedImgLabel = "default";
    private string currentImageFrame = "default";
    private Dictionary<string, string> framesAndBoxes = new Dictionary<string, string>();
    private int currentbb_idx;
    private Texture2D Tim_m_Texture;

    private RenderTexture tempRend;
    private Rect theadjustbb;

    private int fps = 0;
    private byte[] testbytes;
    public class ImgPathData{
        public string rgb_base64;
        public string currentTime;
    }

    public class LabelData
    {
        public string capturedImgName;
        public string label;
        public string bbox;
    }

    public ARCameraManager cameraManager
    {
        get { return m_CameraManager; }
        set { m_CameraManager = value; }
    }

    private void Start()
    {
        Debug.Log("In Start!");
        confirmAll.onClick.AddListener(delegate { confirmallFunction(); });
        showcorrectbtn_list = new int[] { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
    }

    private void Update()
    {
        //Debug.Log("In Update!");
        // check click correct/notcorrect order
        if (Input.touchCount > 0)
        {
            PointerEventData eventDataCurrentPosition = new PointerEventData(EventSystem.current);
            eventDataCurrentPosition.position = new Vector2(Input.GetTouch(0).position.x, Input.GetTouch(0).position.y);
            List<RaycastResult> results = new List<RaycastResult>();
            EventSystem.current.RaycastAll(eventDataCurrentPosition, results);
            if (results.Count > 0)
            {
                string touchcorname = results[1].gameObject.name;
                bool touchnameresult = int.TryParse(touchcorname, out _);
                if (touchnameresult)
                {
                    currentbb_idx = Int32.Parse(touchcorname);
                    print("when touch correct/not button, the order is:");
                    print(currentbb_idx);
                }
            }

        }

        // if need adjust button, drag LU and RB button
        if (adjustBB)
        {
            if (Input.touchCount > 0)
            {
                //print(Input.GetTouch(0).phase);
                //print(EventSystem.current.IsPointerOverGameObject());
                PointerEventData eventDataCurrentPosition = new PointerEventData(EventSystem.current);
                eventDataCurrentPosition.position = new Vector2(Input.GetTouch(0).position.x, Input.GetTouch(0).position.y);
                List<RaycastResult> results = new List<RaycastResult>();
                EventSystem.current.RaycastAll(eventDataCurrentPosition, results);
                
                
                if (results.Count > 0)
                {
                    string touchname = results[0].gameObject.name;
                    //print(touchname);
                    if (touchname== "LUBUTTON")
                    {
                        if (Input.GetTouch(0).phase == TouchPhase.Moved)
                        {
                            print("Touch move phase");
                            Vector3 curPosition = new Vector3(Input.GetTouch(0).position.x, Input.GetTouch(0).position.y, 0);
                            RectTransform lubtn = LU.GetComponent<RectTransform>();
                            lubtn.position = curPosition;
                        }

                    }
                    else if (touchname == "RBBUTTON")
                    {
                        if (Input.GetTouch(0).phase == TouchPhase.Moved)
                        {
                            print("Touch move phase");
                            Vector3 curPosition = new Vector3(Input.GetTouch(0).position.x, Input.GetTouch(0).position.y, 0);
                            RectTransform rbbtn = RB.GetComponent<RectTransform>();
                            rbbtn.position = curPosition;
                        }
                    }
                }

            }
        }
    }

    public void AddBoundingBox()
    {
        numLabels = numLabels + 1;

        class_list[numLabels-1] = "";
        xMin = 300;//float.Parse(labels[i * 4 + 2]);
        yMin = 300;
        xMax = 900;
        yMax = 900;
        boundingBox_list[numLabels - 1] = new Rect(xMin, yMin, (xMax - xMin), (yMax - yMin));//the axis of rect are from left up corner
        boundingBox_label_array[numLabels - 1, 0] = xMin;
        boundingBox_label_array[numLabels - 1, 1] = yMin;
        currentbb_idx = numLabels - 1;

        // show the corresponding correct button and notcorrect button
        correctbtn_list[numLabels - 1] = Instantiate(Correctbtn_prefab).GetComponent<Button>();
        correctbtn_list[numLabels - 1].transform.SetParent(Canvas_prefab.transform, false);
        RectTransform correctbtn = correctbtn_list[numLabels - 1].GetComponent<RectTransform>();
        float correctx = Mathf.Min(Mathf.Max(((xMax + xMin) / 2), 200), 1240);
        float correcty = Mathf.Min(Mathf.Max((sheight - ((yMax + yMin) / 2)), 150), 2910);
        correctbtn.position = new Vector3(correctx, correcty, 0); //the axis of button are from left bottom corner
        correctbtn_list[numLabels - 1].onClick.AddListener(delegate { CorrectButtonFunction(); });
        correctbtn_list[numLabels - 1].gameObject.name = (numLabels - 1).ToString();

        notcorrectbtn_list[numLabels - 1] = Instantiate(NotCorrectbtn_prefab).GetComponent<Button>();
        notcorrectbtn_list[numLabels - 1].transform.SetParent(Canvas_prefab.transform, false);
        RectTransform notcorrectbtn = notcorrectbtn_list[numLabels - 1].GetComponent<RectTransform>();
        float notcorrectx = Mathf.Min(Mathf.Max(((xMax + xMin) / 2), 200), 1240);
        float notcorrecty = Mathf.Min(Mathf.Max((sheight - ((yMax + yMin) / 2)) - 100, 50), 2810);
        notcorrectbtn.position = new Vector3(notcorrectx, notcorrecty, 0);
        notcorrectbtn_list[numLabels - 1].onClick.AddListener(delegate { NotCorrectButtonFunction(); });
        notcorrectbtn_list[numLabels - 1].gameObject.name = (numLabels - 1).ToString();

        cancelbtn_list[numLabels - 1] = Instantiate(cancelbtn_prefab).GetComponent<Button>();
        cancelbtn_list[numLabels - 1].transform.SetParent(Canvas_prefab.transform, false);
        RectTransform cancelbtn = cancelbtn_list[numLabels - 1].GetComponent<RectTransform>();
        float cancelx = Mathf.Min(Mathf.Max(((xMax + xMin) / 2), 200), 1240);
        float cancely = Mathf.Min(Mathf.Max((sheight - ((yMax + yMin) / 2)) - 100, 50), 2710);
        cancelbtn.position = new Vector3(notcorrectx, notcorrecty, 0);
        cancelbtn_list[numLabels - 1].onClick.AddListener(delegate { CancelButtonFunction(); });
        cancelbtn_list[numLabels - 1].gameObject.name = (numLabels - 1).ToString();

        ToAdjustBB();

        correctbtn_list[currentbb_idx].gameObject.SetActive(false);
        notcorrectbtn_list[currentbb_idx].gameObject.SetActive(false);
        cancelbtn_list[currentbb_idx].gameObject.SetActive(false);
        confirmAll.gameObject.SetActive(false);
        for (int i = 0; i < numLabels; i++)
        {
            correctbtn_list[i].gameObject.SetActive(false);
            notcorrectbtn_list[i].gameObject.SetActive(false);
            cancelbtn_list[i].gameObject.SetActive(false);
        }
        showcorrectbtn_list[currentbb_idx] = 0;
    }

    public void ToAdjustBB()
    {
        // not show other bb, just show this adjusting bb
        adjustBB = true;
        renderBB = false;
        ChooseCorrectBBMessage.text = "Please adjust the bounding box";
        Vector3 currbPosition = new Vector3(Mathf.Min(boundingBox_list[currentbb_idx].xMax, swidth), Mathf.Min(sheight - boundingBox_list[currentbb_idx].yMax, sheight), 0);
        RectTransform rbbtn = RB.GetComponent<RectTransform>();
        rbbtn.position = currbPosition;
        RB.gameObject.SetActive(true);
        Vector3 curluPosition = new Vector3(Mathf.Min(boundingBox_list[currentbb_idx].xMin, swidth), Mathf.Min(sheight - boundingBox_list[currentbb_idx].yMin, sheight), 0);
        RectTransform lubtn = LU.GetComponent<RectTransform>();
        lubtn.position = curluPosition;
        LU.gameObject.SetActive(true);
        confirmAdjustBB.gameObject.SetActive(true);
        confirmAdjustBB.onClick.AddListener(delegate { StopAdjustBB(); });
    }

    public void StopAdjustBB()
    {
        adjustBB = false;
        ChooseCorrectBBMessage.text = "";
        RB.gameObject.SetActive(false);
        LU.gameObject.SetActive(false);
        confirmAdjustBB.gameObject.SetActive(false);
        print("confirm the bb:" + currentbb_idx.ToString());

        boundingBox_list[currentbb_idx] = new Rect(LU.GetComponent<RectTransform>().position.x, (sheight - LU.GetComponent<RectTransform>().position.y), (RB.GetComponent<RectTransform>().position.x - LU.GetComponent<RectTransform>().position.x), (LU.GetComponent<RectTransform>().position.y - RB.GetComponent<RectTransform>().position.y));//the axis of rect are from left up corner
        boundingBox_label_array[currentbb_idx, 0] = LU.GetComponent<RectTransform>().position.x;
        boundingBox_label_array[currentbb_idx, 1] = (sheight - LU.GetComponent<RectTransform>().position.y);
        print("the new adjusted bb "+ currentbb_idx.ToString()+"is:");
        print(boundingBox_list[currentbb_idx]);
        print("after the adjustment, current bb is:");
        print(boundingBox_list[0]);
        print(boundingBox_list[1]);
        chooseLabel();
    }

    public void CancelButtonFunction()
    {
        correctbtn_list[currentbb_idx].gameObject.SetActive(false);
        notcorrectbtn_list[currentbb_idx].gameObject.SetActive(false);
        cancelbtn_list[currentbb_idx].gameObject.SetActive(false);
        showcorrectbtn_list[currentbb_idx] = 0;
        boundingBox_label_array[currentbb_idx, 0] = 0;
        boundingBox_label_array[currentbb_idx, 1] = 0;
        boundingBox_label_array[currentbb_idx, 0] = swidth;
        class_list[currentbb_idx] = "";
        boundingBox_list[currentbb_idx] = new Rect(0, 0, 0, 0);

    }

    void chooseLabel()
    {
        ChooseCorrectLabelMessage.text = "Please choose the correct label";
        Classbtn1.gameObject.SetActive(true);
        Classbtn1.onClick.AddListener(delegate { onButton1Click(); });
        Classbtn2.gameObject.SetActive(true);
        Classbtn2.onClick.AddListener(delegate { onButton2Click(); });
        Classbtn3.gameObject.SetActive(true);
        Classbtn3.onClick.AddListener(delegate { onButton3Click(); });
        Classbtn4.gameObject.SetActive(true);
        Classbtn4.onClick.AddListener(delegate { onButton4Click(); });
        Classbtn5.gameObject.SetActive(true);
        Classbtn5.onClick.AddListener(delegate { onButton5Click(); });
    }
    
    IEnumerator PostFilePath(RenderTexture source) {
        DateTime capture_start = DateTime.Now;
        takePicture = false;
        froze = true;
        swidth = source.width;
        sheight = source.height;
        tempRend = RenderTexture.GetTemporary(source.width, source.height);
        Graphics.Blit(source, tempRend);
        Texture2D tempText = new Texture2D(source.width, source.height, TextureFormat.RGBA32, false);

        Rect rect = new Rect(0, 0, source.width, source.height);
        tempText.ReadPixels(rect, 0, 0, false);
        tempText.Apply();
        tempText.Compress(false);
        byte[] bytes = tempText.EncodeToJPG();

        string now = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.ffffff");
        string filePath = Application.persistentDataPath + "/" + now + ".jpg";
        File.WriteAllBytes(filePath, bytes);
            

        if (System.IO.File.Exists(filePath)){
            string img_base64 = Convert.ToBase64String(bytes);

            ImgPathData myObject = new ImgPathData();
            myObject.rgb_base64 =  img_base64;
            myObject.currentTime = now;
            string bodyJsonString = JsonUtility.ToJson(myObject);
            byte[] bodyRaw = Encoding.UTF8.GetBytes(bodyJsonString);
            UnityWebRequest request = new UnityWebRequest(url, "PUT");

            
            request.uploadHandler = (UploadHandler)new UploadHandlerRaw(bodyRaw);
            request.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");
            DateTime capture_end = DateTime.Now;
            print("capture image time");
            print(capture_end - capture_start);
            print("send image time");
            print(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.ffffff"));
            yield return request.SendWebRequest();

            if (request.isNetworkError)
            {
                Debug.Log("Network Error: " + request.error);
            }
            else if (request.isHttpError)
            {
                Debug.Log("Http Error: " + request.error);
            }
            else
            {
                print("receive prediction time");
                print(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.ffffff"));
                Debug.Log("Image path uploaded successfully: " + request.downloadHandler.text);
                string labelsRaw = request.downloadHandler.text;
                string labelsEdited = labelsRaw.Replace('"',' ');
                string labelsEdited1 = labelsEdited.Replace("[", "");
                string labelsEdited2 = labelsEdited1.Replace("]", "");
                string labelsEdited3 = labelsEdited2.Replace(@"\", "");
                //suggestedLabel.text = labelsEdited3[labels.Length - 1];
                print(labelsEdited3);
                string[] labels = labelsEdited3.Split(',');
                print(labels);

                numLabels = int.Parse(labels[0]);
                string capturedImgName = labels[1];
                currentImageFrame = capturedImgName;
                Dictionary<string, int> labelsAndScores = new Dictionary<string, int>();
                    

                //get scores
                //List<int> scores = new List<int>();
                //for (int j = 1; j < numLabels; j++)
                //{
                //    suggestedLabel.text = labels[4];//labels[2 + 4 * numLabels + j].Trim(' ');
                //    if (!labelsAndScores.ContainsKey(labels[2 + 4 * numLabels + j]))
                //    {
                //        labelsAndScores.Add(labels[2 + 4 * numLabels + j].Trim(' '), int.Parse(labels[labels.Length - 1 - 1 * (numLabels - j)]));
                //
                //   }
                //   labelsAndScores[labels[2 + 4 * numLabels + j].Trim(' ')] = int.Parse(labels[labels.Length - 1 - 1 * (numLabels - j)]);
                        
                //}

                ////Display bounding boxes
                string allBboxes = "";
                int[] testxmin = { 100, 500 };
                int[] testxmax = { 1800, 800 };
                int[] testymin = { 100, 500 };
                int[] testymax = { 1800, 800 };

                for (int i = 0; i < numLabels; i++)
                {
                    class_list[i] = labels[numLabels * 4 + 2 + i];
                    string[] bboxes = {labels[i * 4 + 2], labels[i * 4 + 3], labels[i * 4 + 4], labels[i * 4 + 5], "\n" };// {labels[i * 4 + 2], labels[i * 4 + 3], labels[i * 4 + 4], labels[i * 4 + 5], "\n"};
                    xMin = float.Parse(labels[i * 4 + 2]);//testxmin[i];//
                    yMin = float.Parse(labels[i * 4 + 3]);//testymin[i];//
                    xMax = float.Parse(labels[i * 4 + 4]);//testxmax[i];//
                    yMax = float.Parse(labels[i * 4 + 5]);//testymax[i];//

                    print(xMin.ToString()+","+ yMin.ToString() + ","+xMax.ToString() + "," + yMax.ToString());
                    float width = xMax - xMin;
                    float height = yMax - yMin;
                    boundingBox_list[i] = new Rect(xMin, yMin, (xMax-xMin), (yMax-yMin));//the axis of rect are from left up corner
                    boundingBox_label_array[i, 0] = xMin;
                    boundingBox_label_array[i, 1] = yMin;
                    

                    string stringifiedBbox = string.Join(", ", bboxes);
                    allBboxes += stringifiedBbox;


                    // show the corresponding correct button and notcorrect button
                    correctbtn_list[i] = Instantiate(Correctbtn_prefab).GetComponent<Button>();
                    correctbtn_list[i].transform.SetParent(Canvas_prefab.transform, false);
                    RectTransform correctbtn = correctbtn_list[i].GetComponent<RectTransform>();
                    float correctx = Mathf.Min(Mathf.Max(((xMax + xMin) / 2), 200), 1240);
                    float correcty = Mathf.Min(Mathf.Max((sheight - ((yMax + yMin) / 2)), 250), 2910);
                    correctbtn.position = new Vector3(correctx, correcty, 0); //the axis of button are from left bottom corner
                    correctbtn_list[i].onClick.AddListener(delegate { CorrectButtonFunction(); });
                    correctbtn_list[i].gameObject.name = i.ToString();
                    correctbtn_list[i].gameObject.SetActive(true);

                    notcorrectbtn_list[i] = Instantiate(NotCorrectbtn_prefab).GetComponent<Button>();
                    notcorrectbtn_list[i].transform.SetParent(Canvas_prefab.transform, false);
                    RectTransform notcorrectbtn = notcorrectbtn_list[i].GetComponent<RectTransform>();
                    float notcorrectx = Mathf.Min(Mathf.Max(((xMax + xMin) / 2),200), 1240);
                    float notcorrecty = Mathf.Min(Mathf.Max((sheight - ((yMax + yMin) / 2))-100, 150), 2810);
                    notcorrectbtn.position = new Vector3(notcorrectx, notcorrecty, 0);
                    notcorrectbtn_list[i].onClick.AddListener(delegate { NotCorrectButtonFunction(); });
                    notcorrectbtn_list[i].gameObject.name = i.ToString();
                    notcorrectbtn_list[i].gameObject.SetActive(true);

                    cancelbtn_list[i] = Instantiate(cancelbtn_prefab).GetComponent<Button>();
                    cancelbtn_list[i].transform.SetParent(Canvas_prefab.transform, false);
                    RectTransform cancelbtn = cancelbtn_list[i].GetComponent<RectTransform>();
                    float cancelx = Mathf.Min(Mathf.Max(((xMax + xMin) / 2), 200), 1240);
                    float cancely = Mathf.Min(Mathf.Max((sheight - ((yMax + yMin) / 2)) - 200, 50), 2710);
                    cancelbtn.position = new Vector3(cancelx, cancely, 0);
                    cancelbtn_list[i].onClick.AddListener(delegate { CancelButtonFunction(); });
                    cancelbtn_list[i].gameObject.name = i.ToString();
                    cancelbtn_list[i].gameObject.SetActive(true);

                    // after showing the buttons, show the predicted bounding box
                    renderBB = true;
                }
                framesAndBoxes.Add(currentImageFrame, allBboxes);
            }
        }
        else
        {
            print("!System.IO.File.Exists(filePath)");
        }
    }

    void OnDisable()
    {
        print("in ondisable");
        if (m_CameraManager != null)
        {
            //m_CameraManager.frameReceived -= FrameChanged;
            m_CameraManager.frameReceived -= OnCameraFrameReceived;
        }
    }
    unsafe void OnCameraFrameReceived(ARCameraFrameEventArgs eventArgs)
    {
        if (takePicture == true)
        { 
            print("taking photo now");
            takePicture = false;
            froze = true;
            XRCpuImage image;
            print("null after image?");
            if (!cameraManager.TryGetLatestImage(out image))
            {
                print("null before return?");
                return;
            }
            print("null after TryGetLatestImage?");
            // Once we have a valid XRCameraImage, we can access the individual image "planes"
            // (the separate channels in the image). XRCameraImage.GetPlane provides
            // low-overhead access to this data. This could then be passed to a
            // computer vision algorithm. Here, we will convert the camera image
            // to an RGBA texture and draw it on the screen.

            // Choose an RGBA format.
            // See XRCameraImage.FormatSupported for a complete list of supported formats.
            var format = TextureFormat.RGBA32;
            print("null after format?");
            //var format = TextureFormat.Alpha8;

            if (Tim_m_Texture == null || Tim_m_Texture.width != image.width || Tim_m_Texture.height != image.height)
            {
                Tim_m_Texture = new Texture2D(image.width, image.height, format, false);
            }
            print("null after Tim_m_Texture?");
            // Convert the image to format, flipping the image across the Y axis.
            // We can also get a sub rectangle, but we'll get the full image here.
            var conversionParams = new XRCpuImage.ConversionParams(image, format, XRCpuImage.Transformation.MirrorY);
            print("null after conversionParams?");
            // Texture2D allows us write directly to the raw texture data
            // This allows us to do the conversion in-place without making any copies.
            var rawTextureData = Tim_m_Texture.GetRawTextureData<byte>();
            print("null after rawTextureData?");
            try
            {
                image.Convert(conversionParams, new IntPtr(rawTextureData.GetUnsafePtr()), rawTextureData.Length);
                print("null after Convert?");
            }
            finally
            {
                // We must dispose of the XRCameraImage after we're finished
                // with it to avoid leaking native resources.
                image.Dispose();
                print("null after Dispose?");
            }
            
            // Apply the updated texture data to our texture
            Tim_m_Texture.Apply();
            print("finish take the photo");
        }
    }
    IEnumerator TimPostFilePath(RenderTexture source)
    {
        print("start send photo");
        DateTime capture_start = DateTime.Now;
        print(Tim_m_Texture);
        
        byte[] bytes = Tim_m_Texture.EncodeToPNG();

        string now = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.ffffff");
        string filePath = Application.persistentDataPath + "/" + now + ".jpg";
        
        string img_base64 = Convert.ToBase64String(bytes);

        ImgPathData myObject = new ImgPathData();
        myObject.rgb_base64 = img_base64;
        myObject.currentTime = now;
        string bodyJsonString = JsonUtility.ToJson(myObject);
        byte[] bodyRaw = Encoding.UTF8.GetBytes(bodyJsonString);
        UnityWebRequest request = new UnityWebRequest(url, "PUT");
        request.uploadHandler = (UploadHandler)new UploadHandlerRaw(bodyRaw);
        request.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
        request.SetRequestHeader("Content-Type", "application/json");
        DateTime capture_end = DateTime.Now;
        print("capture image time");
        print(capture_end - capture_start);
        print("send image time");
        print(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.ffffff"));
        yield return request.SendWebRequest();

        if (request.isNetworkError)
        {
            Debug.Log("Network Error: " + request.error);
        }
        else if (request.isHttpError)
        {
            Debug.Log("Http Error: " + request.error);
        }
        else
        {
            print("receive prediction time");
            print(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.ffffff"));
            Debug.Log("Image path uploaded successfully: " + request.downloadHandler.text);
            string labelsRaw = request.downloadHandler.text;
            string labelsEdited = labelsRaw.Replace('"', ' ');
            string labelsEdited1 = labelsEdited.Replace("[", "");
            string labelsEdited2 = labelsEdited1.Replace("]", "");
            string labelsEdited3 = labelsEdited2.Replace(@"\", "");
            //suggestedLabel.text = labelsEdited3[labels.Length - 1];
            print(labelsEdited3);
            string[] labels = labelsEdited3.Split(',');
            print(labels);

            numLabels = int.Parse(labels[0]);
            string capturedImgName = labels[1];
            currentImageFrame = capturedImgName;
            Dictionary<string, int> labelsAndScores = new Dictionary<string, int>();

            ////Display bounding boxes
            string allBboxes = "";
            int[] testxmin = { 100, 500 };
            int[] testxmax = { 1800, 800 };
            int[] testymin = { 100, 500 };
            int[] testymax = { 1800, 800 };

            for (int i = 0; i < numLabels; i++)
            {
                class_list[i] = labels[numLabels * 4 + 2 + i];
                string[] bboxes = { labels[i * 4 + 2], labels[i * 4 + 3], labels[i * 4 + 4], labels[i * 4 + 5], "\n" };// {labels[i * 4 + 2], labels[i * 4 + 3], labels[i * 4 + 4], labels[i * 4 + 5], "\n"};
                xMin = float.Parse(labels[i * 4 + 2]);//testxmin[i];//
                yMin = float.Parse(labels[i * 4 + 3]);//testymin[i];//
                xMax = float.Parse(labels[i * 4 + 4]);//testxmax[i];//
                yMax = float.Parse(labels[i * 4 + 5]);//testymax[i];//

                print(xMin.ToString() + "," + yMin.ToString() + "," + xMax.ToString() + "," + yMax.ToString());
                float width = xMax - xMin;
                float height = yMax - yMin;
                boundingBox_list[i] = new Rect(xMin, yMin, (xMax - xMin), (yMax - yMin));//the axis of rect are from left up corner
                boundingBox_label_array[i, 0] = xMin;
                boundingBox_label_array[i, 1] = yMin;


                string stringifiedBbox = string.Join(", ", bboxes);
                allBboxes += stringifiedBbox;


                // show the corresponding correct button and notcorrect button
                correctbtn_list[i] = Instantiate(Correctbtn_prefab).GetComponent<Button>();
                correctbtn_list[i].transform.SetParent(Canvas_prefab.transform, false);
                RectTransform correctbtn = correctbtn_list[i].GetComponent<RectTransform>();
                float correctx = Mathf.Min(Mathf.Max(((xMax + xMin) / 2), 200), 1240);
                float correcty = Mathf.Min(Mathf.Max((sheight - ((yMax + yMin) / 2)), 250), 2910);
                correctbtn.position = new Vector3(correctx, correcty, 0); //the axis of button are from left bottom corner
                correctbtn_list[i].onClick.AddListener(delegate { CorrectButtonFunction(); });
                correctbtn_list[i].gameObject.name = i.ToString();
                correctbtn_list[i].gameObject.SetActive(true);

                notcorrectbtn_list[i] = Instantiate(NotCorrectbtn_prefab).GetComponent<Button>();
                notcorrectbtn_list[i].transform.SetParent(Canvas_prefab.transform, false);
                RectTransform notcorrectbtn = notcorrectbtn_list[i].GetComponent<RectTransform>();
                float notcorrectx = Mathf.Min(Mathf.Max(((xMax + xMin) / 2), 200), 1240);
                float notcorrecty = Mathf.Min(Mathf.Max((sheight - ((yMax + yMin) / 2)) - 100, 150), 2810);
                notcorrectbtn.position = new Vector3(notcorrectx, notcorrecty, 0);
                notcorrectbtn_list[i].onClick.AddListener(delegate { NotCorrectButtonFunction(); });
                notcorrectbtn_list[i].gameObject.name = i.ToString();
                notcorrectbtn_list[i].gameObject.SetActive(true);

                cancelbtn_list[i] = Instantiate(cancelbtn_prefab).GetComponent<Button>();
                cancelbtn_list[i].transform.SetParent(Canvas_prefab.transform, false);
                RectTransform cancelbtn = cancelbtn_list[i].GetComponent<RectTransform>();
                float cancelx = Mathf.Min(Mathf.Max(((xMax + xMin) / 2), 200), 1240);
                float cancely = Mathf.Min(Mathf.Max((sheight - ((yMax + yMin) / 2)) - 200, 50), 2710);
                cancelbtn.position = new Vector3(cancelx, cancely, 0);
                cancelbtn_list[i].onClick.AddListener(delegate { CancelButtonFunction(); });
                cancelbtn_list[i].gameObject.name = i.ToString();
                cancelbtn_list[i].gameObject.SetActive(true);

                // after showing the buttons, show the predicted bounding box
                renderBB = true;
            }
            framesAndBoxes.Add(currentImageFrame, allBboxes);
        } 
    }
    
    public static Texture2D Resize(Texture2D source, int newWidth, int newHeight)
    {
        source.filterMode = FilterMode.Point;
        RenderTexture rt = RenderTexture.GetTemporary(newWidth, newHeight);
        rt.filterMode = FilterMode.Point;
        RenderTexture.active = rt;
        Graphics.Blit(source, rt);
        Texture2D nTex = new Texture2D(newWidth, newHeight);
        nTex.ReadPixels(new Rect(0, 0, newWidth, newHeight), 0, 0);
        //nTex.Apply();
        RenderTexture.active = null;
        RenderTexture.ReleaseTemporary(rt);
        return nTex;
    }

    IEnumerator getencodedimage(RenderTexture source)
    { 
        yield return gettestbytes(source);
    }

    private byte[] gettestbytes(RenderTexture source)
    {
        DateTime before_capture = DateTime.Now;
        source.filterMode = FilterMode.Point;
        RenderTexture rt = RenderTexture.GetTemporary(swidth, swidth);
        rt.filterMode = FilterMode.Point;
        RenderTexture.active = rt;
        Graphics.Blit(source, rt);
        Texture2D tempText = new Texture2D(swidth, swidth);
        tempText.ReadPixels(new Rect(0, 0, swidth, swidth), 0, 0);
        RenderTexture.active = null;
        RenderTexture.ReleaseTemporary(rt);
        //Texture2D tempText = ScreenCapture.CaptureScreenshotAsTexture();
        print("time for capture image:" + (DateTime.Now - before_capture)); 
        //tempText = Resize(tempText, 224, 224);//TextureScale.Scale(tempText, newW, newH);//65ms
        tempText.Compress(true);//1ms
        testbytes = tempText.EncodeToJPG(); //encode takes time160ms //6ms
        print("total capture and encode time:" + (DateTime.Now - before_capture));
        return testbytes;
    }
    IEnumerator testrealtimePostFilePath(RenderTexture source)
    {
        swidth = 224;//1440
        sheight = 224;//2960
        StartCoroutine(getencodedimage(source));
        
        string img_base64 = Convert.ToBase64String(testbytes);

        string now = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.ffffff");
        ImgPathData myObject = new ImgPathData();
        myObject.rgb_base64 = img_base64;
        myObject.currentTime = now;
        string bodyJsonString = JsonUtility.ToJson(myObject);
        byte[] bodyRaw = Encoding.UTF8.GetBytes(bodyJsonString);
        UnityWebRequest webrequest = new UnityWebRequest(url, "PUT");

        webrequest.uploadHandler = (UploadHandler)new UploadHandlerRaw(bodyRaw);
        webrequest.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
        webrequest.SetRequestHeader("Content-Type", "application/json");
        yield return webrequest.SendWebRequest();
        if (webrequest.isNetworkError)
        {
            Debug.Log("Network Error: " + webrequest.error);
        }
        else if (webrequest.isHttpError)
        {
            Debug.Log("Http Error: " + webrequest.error);
        }
        else
        {
            boundingBox_list = new Rect[10];
            boundingBox_label_array = new float[10, 2];
            Debug.Log("Image path uploaded successfully: " + webrequest.downloadHandler.text);
            string labelsRaw = webrequest.downloadHandler.text;
            string labelsEdited = labelsRaw.Replace('"', ' ');
            string labelsEdited1 = labelsEdited.Replace("[", "");
            string labelsEdited2 = labelsEdited1.Replace("]", "");
            string labelsEdited3 = labelsEdited2.Replace(@"\", "");
            //suggestedLabel.text = labelsEdited3[labels.Length - 1];
            print(labelsEdited3);
            string[] labels = labelsEdited3.Split(',');
            print(labels);

            numLabels = int.Parse(labels[0]);
            string capturedImgName = labels[1];
            currentImageFrame = capturedImgName;
            Dictionary<string, int> labelsAndScores = new Dictionary<string, int>();


            //get scores
            //List<int> scores = new List<int>();
            //for (int j = 1; j < numLabels; j++)
            //{
            //    suggestedLabel.text = labels[4];//labels[2 + 4 * numLabels + j].Trim(' ');
            //    if (!labelsAndScores.ContainsKey(labels[2 + 4 * numLabels + j]))
            //    {
            //        labelsAndScores.Add(labels[2 + 4 * numLabels + j].Trim(' '), int.Parse(labels[labels.Length - 1 - 1 * (numLabels - j)]));
            //
            //   }
            //   labelsAndScores[labels[2 + 4 * numLabels + j].Trim(' ')] = int.Parse(labels[labels.Length - 1 - 1 * (numLabels - j)]);

            //}

            ////Display bounding boxes
            string allBboxes = "";
            int[] testxmin = { 100, 500 };
            int[] testxmax = { 1800, 800 };
            int[] testymin = { 100, 500 };
            int[] testymax = { 1800, 800 };

            for (int i = 0; i < numLabels; i++)
            {
                class_list[i] = labels[numLabels * 4 + 2 + i];
                string[] bboxes = { labels[i * 4 + 2], labels[i * 4 + 3], labels[i * 4 + 4], labels[i * 4 + 5], "\n" };// {labels[i * 4 + 2], labels[i * 4 + 3], labels[i * 4 + 4], labels[i * 4 + 5], "\n"};
                xMin = float.Parse(labels[i * 4 + 2]);//testxmin[i];//
                yMin = float.Parse(labels[i * 4 + 3]);//testymin[i];//
                xMax = float.Parse(labels[i * 4 + 4]);//testxmax[i];//
                yMax = float.Parse(labels[i * 4 + 5]);//testymax[i];//

                print(xMin.ToString() + "," + yMin.ToString() + "," + xMax.ToString() + "," + yMax.ToString());
                float width = xMax - xMin;
                float height = yMax - yMin;
                boundingBox_list[i] = new Rect(xMin, yMin, (xMax - xMin), (yMax - yMin));//the axis of rect are from left up corner
                boundingBox_label_array[i, 0] = xMin;
                boundingBox_label_array[i, 1] = yMin;


                string stringifiedBbox = string.Join(", ", bboxes);
                allBboxes += stringifiedBbox;

                // after showing the buttons, show the predicted bounding box
                renderBB = true;
            }
            framesAndBoxes.Add(currentImageFrame, allBboxes);
        }


    }


    IEnumerator PostLabel(string imageLabelToSave, string imageFrameToSave)
    {
        print("In PostLabel");
        LabelData myLabel = new LabelData();
        myLabel.capturedImgName =imageFrameToSave;
        myLabel.label = imageLabelToSave;
        myLabel.bbox = framesAndBoxes[imageFrameToSave];

        string bodyJsonString = JsonUtility.ToJson(myLabel);
        var request = new UnityWebRequest(url2, "PUT");
        byte[] bodyRaw = Encoding.UTF8.GetBytes(bodyJsonString);

        request.uploadHandler = (UploadHandler)new UploadHandlerRaw(bodyRaw);
        request.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
        request.SetRequestHeader("Content-Type", "application/json");
        yield return request.SendWebRequest();
        if (request.isNetworkError)
        {
            Debug.Log("Network Error: " + request.error);
        }
        else if (request.isHttpError)
        {
            Debug.Log("Http Error: " + request.error);
        }
        else
        {
            Debug.Log("Success");
        }
    }

    void CorrectButtonFunction()
    {
        print("click");
        print(currentbb_idx);
        correctbtn_list[currentbb_idx].gameObject.SetActive(false);
        notcorrectbtn_list[currentbb_idx].gameObject.SetActive(false);
        cancelbtn_list[currentbb_idx].gameObject.SetActive(false);
        showcorrectbtn_list[currentbb_idx] = 0;
    }

    void NotCorrectButtonFunction()
    {
        print("notcorrect, will adjust bb:" + currentbb_idx.ToString());
        print("current bb:");
        print(boundingBox_list[0]);
        print(boundingBox_list[1]);
        ToAdjustBB();
        
        correctbtn_list[currentbb_idx].gameObject.SetActive(false);
        notcorrectbtn_list[currentbb_idx].gameObject.SetActive(false);
        cancelbtn_list[currentbb_idx].gameObject.SetActive(false);
        confirmAll.gameObject.SetActive(false);
        for (int i = 0; i < numLabels; i++) {
            correctbtn_list[i].gameObject.SetActive(false);
            notcorrectbtn_list[i].gameObject.SetActive(false);
            cancelbtn_list[i].gameObject.SetActive(false);
        }
        showcorrectbtn_list[currentbb_idx] = 0;
    }

    void confirmallFunction()
    {
        
        renderBB = false;
        froze = false;
        RenderTexture.ReleaseTemporary(tempRend);
        Classbtn1.gameObject.SetActive(false);
        Classbtn2.gameObject.SetActive(false);
        Classbtn3.gameObject.SetActive(false);
        Classbtn4.gameObject.SetActive(false);
        Classbtn5.gameObject.SetActive(false);
        confirmAll.gameObject.SetActive(false);
        for (int i = 0; i < numLabels; i++) {
            correctbtn_list[i].gameObject.SetActive(false);
            notcorrectbtn_list[i].gameObject.SetActive(false);
            cancelbtn_list[i].gameObject.SetActive(false);
        }
        showcorrectbtn_list = new int[] { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
    }

    void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        if (!froze)
        {
            Graphics.Blit(source, destination);
        }
        else
        {
            Graphics.Blit(tempRend, destination);
        }
        if (takePicture)
        {
            StartCoroutine(TimPostFilePath(source));
        }
        /*
        fps++;

        if (fps == 120)
        {
            print(fps);
            fps = 0;
            takePicture = true;
            if (takePicture)
            {
                StartCoroutine(testrealtimePostFilePath(source));
            }
        }
        */
    }
    public void TakePhoto()
    {
        takePicture = true;
        confirmAll.gameObject.SetActive(true);
        if (m_CameraManager != null)
        {
            print("framereceived");
            m_CameraManager.frameReceived += OnCameraFrameReceived;
        }
    }

    void OnGUI()
    {
        //print("In OnGUI"+ renderBB);
        if (renderBB)
        {
            // Debug.Log(renderBB);
            GUI.skin = guiSkin;
            GUI.color = Color.red;
            GUI.skin.label.fontSize = 50;



            for (int i = 0; i < numLabels; i++)
            {
                //GUIContent content = new GUIContent(BoxTexture, class_list[i]);
                //print("Renderbb:");
                //print(boundingBox_list[i]);
                GUI.Label(new Rect(boundingBox_label_array[i, 0], boundingBox_label_array[i, 1], swidth - boundingBox_label_array[i, 0], 300), class_list[i]);
                GUI.Box(boundingBox_list[i], BoxTexture);
            }


            // Button BB = clickableBoundingBox.GetComponent<Button>();
            // Vector3 pos = new Vector3(xMin, yMin, 0);
            // float width = xMax - xMin;
            // float height = yMax - yMin;
            // Vector3 scale = new Vector3(width, height, 0);
            // BB.transform.position = pos;
            // // BB.transform.lossyScale = scale; //this needs to be modified
            // BB.onClick.AddListener(TaskOnClick);
        }

        if (adjustBB)
        {
            // Debug.Log(renderBB);
            GUI.skin = guiSkin;
            GUI.color = Color.red;
            RectTransform Templubtn = LU.GetComponent<RectTransform>();
            RectTransform TempRBbtn = RB.GetComponent<RectTransform>();
            
            theadjustbb = new Rect(Templubtn.position.x, (sheight - Templubtn.position.y), (TempRBbtn.position.x - Templubtn.position.x), (Templubtn.position.y - TempRBbtn.position.y));
            GUI.Box(theadjustbb, BoxTexture);

        }
    }

    public void onConfirmLabel()
    {
        selectedImgLabel = suggestedLabel.text;     
        onCapture();

    }

    public void onButton1Click()
    {
        
        selectedImgLabel = "BLACK-AND-WHITE-RUFFED-LEMUR";
        ChooseCorrectLabelMessage.text = "";
        class_list[currentbb_idx] = selectedImgLabel;
        correctbtn_list[currentbb_idx].gameObject.SetActive(false);
        notcorrectbtn_list[currentbb_idx].gameObject.SetActive(false);
        cancelbtn_list[currentbb_idx].gameObject.SetActive(false);
        confirmAll.gameObject.SetActive(true);
        showcorrectbtn_list[currentbb_idx] = 0;
        onCapture();

    }

    public void onButton2Click()
    {
        selectedImgLabel = "BLUE-AND-BLACK-EYED-LEMUR";
        ChooseCorrectLabelMessage.text = "";
        class_list[currentbb_idx] = selectedImgLabel;
        correctbtn_list[currentbb_idx].gameObject.SetActive(false);
        notcorrectbtn_list[currentbb_idx].gameObject.SetActive(false);
        cancelbtn_list[currentbb_idx].gameObject.SetActive(false);
        confirmAll.gameObject.SetActive(true);
        showcorrectbtn_list[currentbb_idx] = 0;
        onCapture();

    }

    public void onButton3Click()
    {
        selectedImgLabel = "COQUERELS-SIFAKA";
        ChooseCorrectLabelMessage.text = "";
        class_list[currentbb_idx] = selectedImgLabel;
        correctbtn_list[currentbb_idx].gameObject.SetActive(false);
        notcorrectbtn_list[currentbb_idx].gameObject.SetActive(false);
        cancelbtn_list[currentbb_idx].gameObject.SetActive(false);
        confirmAll.gameObject.SetActive(true);
        showcorrectbtn_list[currentbb_idx] = 0;
        onCapture();

    }

    public void onButton4Click()
    {
        selectedImgLabel = "RED-RUFFED-LEMUR";
        ChooseCorrectLabelMessage.text = "";
        class_list[currentbb_idx] = selectedImgLabel;
        correctbtn_list[currentbb_idx].gameObject.SetActive(false);
        notcorrectbtn_list[currentbb_idx].gameObject.SetActive(false);
        cancelbtn_list[currentbb_idx].gameObject.SetActive(false);
        confirmAll.gameObject.SetActive(true);
        showcorrectbtn_list[currentbb_idx] = 0;
        onCapture();
    }

    public void onButton5Click()
    {
        selectedImgLabel = "RING-TAILED-LEMUR";
        ChooseCorrectLabelMessage.text = "";
        class_list[currentbb_idx] = selectedImgLabel;
        correctbtn_list[currentbb_idx].gameObject.SetActive(false);
        notcorrectbtn_list[currentbb_idx].gameObject.SetActive(false);
        cancelbtn_list[currentbb_idx].gameObject.SetActive(false);
        confirmAll.gameObject.SetActive(true);
        showcorrectbtn_list[currentbb_idx] = 0;
        onCapture();
    }

    public void onCapture()
    {
        //StartCoroutine(PostLabel(selectedImgLabel, currentImageFrame));
        //RenderTexture.ReleaseTemporary(tempRend);
        //froze = false;
        //renderBB = false;
        //for (int i = 0; i < numLabels; i++) {
        //    correctbtn_list[i].gameObject.SetActive(false);
        //    notcorrectbtn_list[i].gameObject.SetActive(false);
        //}
        Classbtn1.gameObject.SetActive(false);
        Classbtn2.gameObject.SetActive(false);
        Classbtn3.gameObject.SetActive(false);
        Classbtn4.gameObject.SetActive(false);
        Classbtn5.gameObject.SetActive(false);
        renderBB = true;
        for (int i = 0; i < numLabels; i++)
        {
            
            if(showcorrectbtn_list[i] == 1)
            {
                correctbtn_list[i].gameObject.SetActive(true);
                notcorrectbtn_list[i].gameObject.SetActive(true);
                cancelbtn_list[i].gameObject.SetActive(true);
            }
        }

    }

}

