﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using System.IO;
using System;
using TMPro;
using System.Text;
using System.Linq;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using Unity.Collections.LowLevel.Unsafe;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;
using System.Diagnostics;

using System.Threading.Tasks;
using UnityEngine.Experimental.Rendering;
using UnityEngine.Rendering;


public class Screenshot : MonoBehaviour
{
    [SerializeField]

    bool takePicture = false;
    bool froze = false;

    private int test_cnt = 0;

    public Text guidance;
    public TextMeshProUGUI back_div;
    public TextMeshProUGUI ins_div;
    public TextMeshProUGUI back_div1;
    public TextMeshProUGUI ins_div1;
    public TextMeshProUGUI taken_num;
    public GameObject Canvas_prefab;
    public Button TakeNextPhoto;
    public Button StartTakePhoto;
    public Button StartCollectData;

    private readonly string urlguidance = "http://192.168.0.4:1200/guidance";//10.148.54.32:5958/guidance";
    private readonly string urlrealtimeguidance = "http://192.168.0.4:1200/realtimeguidance";//10.148.54.32:5958/realtimeguidance";

    private int swidth;
    private int sheight;

    private RenderTexture tempRend;

    private int fps = 0;
    public class ImgPathData{
        public string rgb_base64;
        public string currentTime;
    }

    private void Start()
    {
        UnityEngine.Debug.Log("In Start!");  
        TakeNextPhoto.onClick.AddListener(delegate { TakeNextPhotoClick(); });
        StartCollectData.onClick.AddListener(delegate { StartCollectDataClick(); });
    }

    private void Update()
    {
    }

    private static void WriteString(string text)
    {
        string path = Application.persistentDataPath + "/test.txt";
        print(path);
        //Write some text to the test.txt file
        StreamWriter writer = new StreamWriter(path, true);
        writer.WriteLine(text + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.ffffff"));
        writer.Close();
        //StreamReader reader = new StreamReader(path);
        //Print the text from the file
        //UnityEngine.Debug.Log(reader.ReadToEnd());
        //reader.Close();
    }

    IEnumerator PostImages(RenderTexture source)
    {
        DateTime capture_start = DateTime.Now;
        takePicture = false;
        froze = true; // so that onRenderImage will not show real time camera images, and will stay on current image
        print("start capture image time" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.ffffff"));
        //print(capture_start);
        //print(source.width);
        //print(source.height);
        swidth = 720;// source.width;
        sheight = 1480;// source.height;

        //create a user-defined size renderTexture and put current image into this texture
        tempRend = RenderTexture.GetTemporary(swidth, sheight);
        Graphics.Blit(source, tempRend);
        Texture2D tempText = new Texture2D(swidth, sheight, TextureFormat.RGBA32, false);
        Rect rect = new Rect(0, 0, swidth, sheight);
        tempText.ReadPixels(rect, 0, 0, false);
        tempText.Apply();
        tempText.Compress(false);
        //encode and wrap image into ImgPathData object
        byte[] bytes = tempText.EncodeToJPG();
        string now = DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss_ffffff");
        string img_base64 = Convert.ToBase64String(bytes);
        ImgPathData myObject = new ImgPathData();
        myObject.rgb_base64 = img_base64;
        myObject.currentTime = "target_"+now;
        //send in Json format
        string bodyJsonString = JsonUtility.ToJson(myObject);
        byte[] bodyRaw = Encoding.UTF8.GetBytes(bodyJsonString);
        //send images
        UnityWebRequest request = new UnityWebRequest(urlguidance, "PUT");
        request.uploadHandler = (UploadHandler)new UploadHandlerRaw(bodyRaw);
        request.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
        request.SetRequestHeader("Content-Type", "application/json");
        DateTime capture_end = DateTime.Now;
        print("send image time" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.ffffff"));
        WriteString("send image time");
        yield return request.SendWebRequest();

        if (request.isNetworkError)
        {
            UnityEngine.Debug.Log("Network Error: " + request.error);
        }
        else if (request.isHttpError)
        {
            UnityEngine.Debug.Log("Http Error: " + request.error);
        }
        else
        {
            WriteString("receive guidance time" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.ffffff"));
            print("receive guidance time"+ DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.ffffff"));
            //print(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.ffffff"));
            UnityEngine.Debug.Log("Image path uploaded successfully: " + request.downloadHandler.text);
            string labelsRaw = request.downloadHandler.text;
            string labelsEdited = labelsRaw.Replace("\"", "");
            string labelsEdited0 = labelsEdited.Replace(@"\", "");
            string labelsEdited1 = labelsEdited0.Replace(" ", "");
            string[] guid_num = labelsEdited1.Split('+');
            print(labelsEdited1);
            print(guid_num[0]);
            if (guid_num[0]=="0")//if (labelsEdited1 == "0")
            {
                test_cnt += 1;
                guidance.text = "Good job! Please change your position and take next photo!";
                guidance.color = Color.blue;
                froze = false;
                RenderTexture.ReleaseTemporary(tempRend);
                Destroy(tempText);
                tempText = null;
                TakeNextPhoto.gameObject.SetActive(true);
            }
            else if (guid_num[0] == "1")//else if (labelsEdited1 == "1")
            {
                guidance.color = Color.red;
                guidance.text = "<color=blue>Oops, sorry again! Please</color>\n"+ guid_num[1] + "\n<color=blue>and retake a photo!</color>";
                
                froze = false;
                RenderTexture.ReleaseTemporary(tempRend);
                Destroy(tempText);
                tempText = null;
                TakeNextPhoto.gameObject.SetActive(true);
            }
            else if (guid_num[0] == "2")//else if (labelsEdited1 == "2")
            {
                guidance.color = Color.red;
                guidance.text = "<color=blue>Sorry! Please</color>\n" + guid_num[1] + "\n<color=blue>and retake a photo!</color>";
                
                froze = false;
                RenderTexture.ReleaseTemporary(tempRend);
                Destroy(tempText);
                tempText = null;
                TakeNextPhoto.gameObject.SetActive(true);
            }
            else if (guid_num[0] == "3")//else if (labelsEdited1 == "3")
            {
                guidance.color = Color.red;
                guidance.text = "<color=blue>Oops, sorry again! Please</color>\n" + guid_num[1] + "\n<color=blue>and retake a photo!</color>";
                
                froze = false;
                RenderTexture.ReleaseTemporary(tempRend);
                Destroy(tempText);
                tempText = null;
                TakeNextPhoto.gameObject.SetActive(true);
            }
            else if (guid_num[0] == "4")//else if (labelsEdited1 == "3")
            {
                guidance.color = Color.red;
                guidance.text = "<color=blue>Sorry! Please</color>\n" + guid_num[1] + "\n<color=blue>and retake a photo!</color>";
                
                froze = false;
                RenderTexture.ReleaseTemporary(tempRend);
                Destroy(tempText);
                tempText = null;
                TakeNextPhoto.gameObject.SetActive(true);
            }
            else if (guid_num[0] == "5")//else if (labelsEdited1 == "3")
            {
                guidance.color = Color.red;
                guidance.text = "<color=blue>Oops, sorry again! Please</color>\n" + guid_num[1] + "\n<color=blue>and retake a photo!</color>";
                
                froze = false;
                RenderTexture.ReleaseTemporary(tempRend);
                Destroy(tempText);
                tempText = null;
                TakeNextPhoto.gameObject.SetActive(true);
            }
            else if (guid_num[0] == "6")//else if (labelsEdited1 == "3")
            {
                guidance.color = Color.red;
                guidance.text = "<color=blue>Sorry! Please</color>\n" + guid_num[1] + "\n<color=blue>and retake a photo!</color>";
                
                froze = false;
                RenderTexture.ReleaseTemporary(tempRend);
                Destroy(tempText);
                tempText = null;
                TakeNextPhoto.gameObject.SetActive(true);
            }
            else
            {
                test_cnt += 1;
                guidance.text = "Perfect! You've collected 30 images for this object. Time to take phothos for next object!";
                guidance.color = Color.black;
                froze = true; //Modified April.02
                RenderTexture.ReleaseTemporary(tempRend);
                Destroy(tempText);
                tempText = null;
                StartCollectData.gameObject.SetActive(true);
            }
        }
    }

    IEnumerator PostRealtimeImages(RenderTexture source)
    {
        print("time of start process and send image:"+DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss_ffffff"));
        TakeNextPhoto.gameObject.SetActive(false);
        //back_div.text = "Estimating";
        //back_div.color = Color.black;
        //ins_div.text = "Estimating";
        //ins_div.color = Color.black;
        //back_div1.text = "Estimating";
        //back_div1.color = Color.black;
        //ins_div1.text = "Estimating";
        //ins_div1.color = Color.black;
        StartTakePhoto.gameObject.SetActive(false);
        DateTime capture_start = DateTime.Now;
        froze = true; // so that onRenderImage will not show real time camera images, and will stay on current image
        swidth = 720;// source.width;
        sheight = 1480;// source.height;
        print("in post realtime images");
        //create a user-defined size renderTexture and put current image into this texture
        tempRend = RenderTexture.GetTemporary(swidth, sheight);
        Graphics.Blit(source, tempRend);
        Texture2D tempText = new Texture2D(swidth, sheight, TextureFormat.RGBA32, false);
        Rect rect = new Rect(0, 0, swidth, sheight);
        tempText.ReadPixels(rect, 0, 0, false);
        tempText.Apply();
        tempText.Compress(false);
        //encode and wrap image into ImgPathData object
        byte[] bytes = tempText.EncodeToJPG();
        string now = DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss_ffffff");

        string img_base64 = Convert.ToBase64String(bytes);
        ImgPathData myObject = new ImgPathData();
        myObject.rgb_base64 = img_base64;
        myObject.currentTime = "target_" + now;
        //send in Json format
        string bodyJsonString = JsonUtility.ToJson(myObject);
        byte[] bodyRaw = Encoding.UTF8.GetBytes(bodyJsonString);
        //send images
        UnityWebRequest request = new UnityWebRequest(urlrealtimeguidance, "PUT");
        request.uploadHandler = (UploadHandler)new UploadHandlerRaw(bodyRaw);
        request.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
        request.SetRequestHeader("Content-Type", "application/json");
        DateTime capture_end = DateTime.Now;
        yield return request.SendWebRequest();
        if (request.isNetworkError)
        {
            UnityEngine.Debug.Log("Network Error: " + request.error);
        }
        else if (request.isHttpError)
        {
            UnityEngine.Debug.Log("Http Error: " + request.error);
        }
        else
        {
            print("receive guidance time:" + DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss_ffffff"));
            //print(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.ffffff"));
            UnityEngine.Debug.Log("Image path uploaded successfully: " + request.downloadHandler.text);
            string labelsRaw = request.downloadHandler.text;
            string labelsEdited = labelsRaw.Replace("\"", "");
            string labelsEdited0 = labelsEdited.Replace(@"\", "");
            string labelsEdited1 = labelsEdited0.Replace(" ", "");
            string labelsEdited2 = labelsEdited1.Replace("[", "");
            string labelsEdited3 = labelsEdited2.Replace("]", "");
            string labelsEdited4 = labelsEdited3.Replace("\'", "");
            //print(labelsEdited1);
            //string[] div = labelsEdited4.Split(',');
            //back_div.text = div[0];
            //back_div1.text = div[0];
            //if (div[0] == "Reject")
            //{
            //    back_div.color = Color.red;
            //    back_div1.color = Color.red;
            //}
            //else 
            //{
            //    back_div.color = Color.blue;
            //    back_div1.color = Color.blue;
            //}
            //ins_div.text = div[1];
            //ins_div1.text = div[1];
            //if (div[1] == "Reject")
            //{
            //    ins_div.color = Color.red;
            //    ins_div1.color = Color.red;
            //}
            //else
            //{
            //    ins_div.color = Color.blue;
            //    ins_div1.color = Color.blue;
            //}

            froze = false;
            RenderTexture.ReleaseTemporary(tempRend);
            Destroy(tempText);
            tempText = null;
            TakeNextPhoto.gameObject.SetActive(true);
            StartTakePhoto.gameObject.SetActive(true);
        }  
    }

    void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        //print("onrenderimage happens:" + DateTime.Now.ToString("yyyy_MM_dd_HH_mm_ss_ffffff"));
        //print("in on render image");
        if (!froze)
        {
            print("before blit");
            Graphics.Blit(source, destination);
            print("after blit");
        }
        else
        {
            Graphics.Blit(tempRend, destination);
        }
        
        if (takePicture)
        {
            print("before PostImages");
            StartCoroutine(PostImages(source));
            print("after PostImages");
        }

        taken_num.text = test_cnt.ToString();

        //fps++;
        //
        //if (fps == 120)
        //{
        ///   print(fps);
        //    fps = 0;
            
        //    if ((!froze) && (!takePicture))
        //    {
        //        //print("before post real time images");
        //        StartCoroutine(PostRealtimeImages(source));
        //        //print("after post real time images");
        //    }  
            
        //}
        
    }
    public void TakePhoto()
    {
        takePicture = true;
        print("start take a photo"+DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.ffffff"));
    }

    void OnGUI()
    {
    }

    public void TakeNextPhotoClick()
    {
        TakeNextPhoto.gameObject.SetActive(false);
        //print("TakeNextPhotoClick happens here!!!" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.ffffff"));
    }

    public void StartCollectDataClick()
    {
        froze = false;
        TakeNextPhoto.gameObject.SetActive(true);
        StartCollectData.gameObject.SetActive(false);
    }

}

