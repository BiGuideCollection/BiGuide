# Copyright (c) OpenMMLab. All rights reserved.
from .cbam import CBAM

__all__ = ['CBAM']
