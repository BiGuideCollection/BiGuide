Tips: 这个是自定义数据集的 config 文件，请结合 [自定义数据集教程](https://github.com/open-mmlab/mmyolo/blob/dev/docs/zh_cn/user_guides/custom_dataset.md) 来使用。

Tips: This is the config file of the custom dataset. Please use it in combination with [custom dataset](https://github.com/open-mmlab/mmyolo/blob/dev/docs/en/user_guides/custom_dataset.md).
