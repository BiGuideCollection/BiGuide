# Copyright (c) OpenMMLab. All rights reserved.
from projects.assigner_visualization.detectors.yolo_detector_assigner import \
    YOLODetectorAssigner

__all__ = ['YOLODetectorAssigner']
